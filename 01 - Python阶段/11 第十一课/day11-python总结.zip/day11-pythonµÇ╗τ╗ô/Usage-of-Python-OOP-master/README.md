# Python面向对象简单用法
这里是每个文件包括的内容的说明  
Python版本：
## 一、面向对象基础及Python面向对象语法
1.用Python定义类 —— defClass.py  
2.定义类的属性 —— defProperties.py  
3.定义类的方法 —— defMethod.py  
4.类的继承 —— classInheritance.py  
5.类的多态 —— classPolymorphism.py  
## 二、深入Python面向对象及Magic Method简介
1.对象的实例化 —— magicMethod-instantiation_of_object.py  
2.类的运算 —— magicMethod-operation_of_class.py  
3.类的展现 —— magicMethod-display_of_class.py  
4.类的属性设置 —— magicMethod-property_of_class.py
